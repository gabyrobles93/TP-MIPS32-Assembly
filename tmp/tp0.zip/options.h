
//Desplega los argumentos que pueden ser utilizados para la ejecución del programa.
void help();

//Devuelve la version del trabajo práctico.
void version();



